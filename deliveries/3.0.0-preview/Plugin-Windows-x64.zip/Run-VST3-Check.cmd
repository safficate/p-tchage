@echo off
"%~dp0validation-tools\WindowsVst3Audio.exe" "%~dp0Microtonal Pitch Map Pro.vst3\Contents\x86_64-win\Microtonal Pitch Map Pro.vst3" > "%~dp0LOCAL-VST3-TEST.log" 2>&1
set "PitchMapExit=%errorlevel%"
type "%~dp0LOCAL-VST3-TEST.log"
echo Exit code: %PitchMapExit%
echo This checks the DLL, not Cakewalk Sonar compatibility.
pause
exit /b %PitchMapExit%
