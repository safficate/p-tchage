Optional Windows console tools, not Sonar certification.
Run WindowsVst3Audio.exe with the actual VST3 DLL path, or use Run-VST3-Check.cmd.
Run RegionalTests.exe C:\PitchMap-Corpus to regenerate synthetic WAV/CSV/JSON.
No Python, MIDI or external interface is needed for these executables.
