@echo off
"Z:\workspace\p-tchage\build-win-clang\PitchTests_artefacts\Release\PitchTests.exe"  > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\engine.log" 2>&1
echo %errorlevel% > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\engine.code"
"Z:\workspace\p-tchage\build-win-clang\LiveTests_artefacts\Release\LiveTests.exe" "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\audio-examples" > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\live.log" 2>&1
echo %errorlevel% > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\live.code"
"Z:\workspace\p-tchage\build-win-clang\PluginTests_artefacts\Release\PluginTests.exe" "--audio-only" > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\state.log" 2>&1
echo %errorlevel% > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\state.code"
"Z:\workspace\p-tchage\build-win-clang\ARATests_artefacts\Release\ARATests.exe"  > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\ara.log" 2>&1
echo %errorlevel% > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\ara.code"
"Z:\workspace\p-tchage\build-win-clang\WindowsVst3Audio.exe" "Z:\workspace\p-tchage\build-win-clang\MicrotonalPitchMapPro_artefacts\Release\VST3\Microtonal Pitch Map Pro.vst3\Contents\x86_64-win\Microtonal Pitch Map Pro.vst3" > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\actual-vst3.log" 2>&1
echo %errorlevel% > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\actual-vst3.code"
