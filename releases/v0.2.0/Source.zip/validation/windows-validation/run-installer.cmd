@echo off
start /wait "" "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\MicrotonalPitchMapPro-Setup-x64.exe" /S > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\install.log" 2>&1
echo %errorlevel% > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\install.code"
"Z:\workspace\.cloud-tools\WindowsVst3Smoke.exe" "C:\Program Files\Common Files\VST3\Microtonal Pitch Map Pro.vst3\Contents\x86_64-win\Microtonal Pitch Map Pro.vst3" > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\installed-vst3.log" 2>&1
echo %errorlevel% > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\installed-vst3.code"
reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\Uninstall\MicrotonalPitchMapPro" > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\install-registry.log" 2>&1
start /wait "" "C:\Program Files\Microtonal Pitch Map Pro\Uninstall.exe" /S
echo %errorlevel% > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\uninstall.code"
echo Uninstall command returned > "Z:\workspace\p-tchage\dist\windows-x64-0.2.0\windows-validation\uninstall.log"
